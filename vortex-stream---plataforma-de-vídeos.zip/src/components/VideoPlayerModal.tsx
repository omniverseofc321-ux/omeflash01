import React, { useEffect } from 'react';
import { X, Play, Clock, ExternalLink } from 'lucide-react';
import { Video } from '../types.ts';

interface VideoPlayerModalProps {
  video: Video | null;
  onClose: () => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({ video, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!video) return null;

  const isYouTube = video.video_url.includes('youtube.com') || video.video_url.includes('youtu.be');
  const isVimeo = video.video_url.includes('vimeo.com');

  const getYouTubeEmbedUrl = (url: string) => {
    let videoId = '';
    if (url.includes('youtu.be/')) {
      videoId = url.split('youtu.be/')[1]?.split('?')[0] || '';
    } else if (url.includes('watch?v=')) {
      videoId = url.split('watch?v=')[1]?.split('&')[0] || '';
    } else if (url.includes('embed/')) {
      return url;
    }
    return videoId ? `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1` : url;
  };

  const getVimeoEmbedUrl = (url: string) => {
    const match = url.match(/vimeo\.com\/(\d+)/);
    return match ? `https://player.vimeo.com/video/${match[1]}?autoplay=1` : url;
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-3xl overflow-hidden rounded-3xl bg-zinc-900 border border-white/[0.1] shadow-2xl flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Compacto */}
        <div className="flex items-center justify-between border-b border-white/[0.08] px-4 py-3 sm:px-5">
          <div className="flex items-center gap-2 min-w-0 pr-3">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-rose-500/10 text-rose-500">
              <Play className="h-3 w-3 fill-current" />
            </span>
            <h3 className="text-sm font-semibold text-white truncate">
              {video.title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="flex items-center justify-center min-h-[44px] min-w-[44px] -mr-2 rounded-xl text-zinc-400 hover:text-white transition"
            aria-label="Fechar player"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Player Container */}
        <div className="relative aspect-video w-full bg-black shrink-0">
          {isYouTube ? (
            <iframe
              src={getYouTubeEmbedUrl(video.video_url)}
              title={video.title}
              className="h-full w-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : isVimeo ? (
            <iframe
              src={getVimeoEmbedUrl(video.video_url)}
              title={video.title}
              className="h-full w-full border-0"
              allow="autoplay; fullscreen; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <video
              src={video.video_url}
              controls
              autoPlay
              playsInline
              poster={video.thumbnail_url}
              className="h-full w-full object-contain"
            >
              Seu navegador não suporta a tag de vídeo HTML5.
            </video>
          )}
        </div>

        {/* Metadados e Descrição */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-3">
          {/* Metadados limpos sem pills */}
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-zinc-400">
            <span className="font-semibold text-rose-400">{video.category}</span>
            {video.duration && (
              <>
                <span aria-hidden="true" className="text-zinc-600">·</span>
                <span className="flex items-center gap-1 font-mono text-zinc-300">
                  <Clock className="h-3 w-3 text-zinc-500" />
                  {video.duration}
                </span>
              </>
            )}
            <span aria-hidden="true" className="text-zinc-600">·</span>
            <span>{new Date(video.created_at).toLocaleDateString('pt-BR')}</span>

            <a
              href={video.video_url}
              target="_blank"
              rel="noopener noreferrer"
              className="ml-auto inline-flex items-center gap-1 text-[11px] text-zinc-400 hover:text-white transition"
            >
              <ExternalLink className="h-3 w-3" />
              <span>Link direto</span>
            </a>
          </div>

          <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed whitespace-pre-line bg-zinc-950/70 p-3.5 rounded-2xl border border-white/[0.06]">
            {video.description}
          </p>
        </div>
      </div>
    </div>
  );
};
