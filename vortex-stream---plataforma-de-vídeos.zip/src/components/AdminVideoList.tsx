import React, { useState, useEffect } from 'react';
import { 
  Film, 
  Search, 
  Plus, 
  Edit3, 
  Trash2, 
  Eye, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  RefreshCw, 
  ExternalLink,
  Tag,
  X,
  Play
} from 'lucide-react';
import { Video, VideoStatus } from '../types.ts';
import { getAdminVideos, updateAdminVideoStatus, deleteAdminVideo } from '../lib/api.ts';
import { VideoPlayerModal } from './VideoPlayerModal.tsx';

interface AdminVideoListProps {
  onAddNew: () => void;
  onEditVideo: (video: Video) => void;
}

export const AdminVideoList: React.FC<AdminVideoListProps> = ({ onAddNew, onEditVideo }) => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filtros
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'draft'>('all');
  const [categoryFilter, setCategoryFilter] = useState('Todas');

  // Modal de Exclusão
  const [videoToDelete, setVideoToDelete] = useState<Video | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Modal de Detalhes
  const [videoToView, setVideoToView] = useState<Video | null>(null);

  // Modal de Reprodução
  const [videoToPlay, setVideoToPlay] = useState<Video | null>(null);

  // Feedback de Sucesso
  const [feedback, setFeedback] = useState<string | null>(null);

  const fetchVideos = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await getAdminVideos({
        search,
        status: statusFilter,
        category: categoryFilter,
      });
      setVideos(res.videos);
      setCategories(['Todas', ...res.categories]);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Erro ao listar vídeos.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVideos();
  }, [statusFilter, categoryFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchVideos();
  };

  const handleToggleStatus = async (video: Video) => {
    const newStatus: VideoStatus = video.status === 'published' ? 'draft' : 'published';
    try {
      await updateAdminVideoStatus(video.id, newStatus);
      setVideos((prev) =>
        prev.map((v) => (v.id === video.id ? { ...v, status: newStatus } : v))
      );
      setFeedback(`Status de "${video.title}" alterado para ${newStatus === 'published' ? 'Publicado' : 'Rascunho'}.`);
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Falha ao alterar status.';
      setError(msg);
    }
  };

  const handleConfirmDelete = async () => {
    if (!videoToDelete) return;
    try {
      setDeleting(true);
      await deleteAdminVideo(videoToDelete.id);
      setVideos((prev) => prev.filter((v) => v.id !== videoToDelete.id));
      setFeedback(`Vídeo "${videoToDelete.title}" excluído do banco de dados.`);
      setVideoToDelete(null);
      setTimeout(() => setFeedback(null), 3500);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Falha ao excluir vídeo.';
      setError(msg);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Header & Barra de Ações */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Film className="h-5 w-5 sm:h-6 sm:w-6 text-rose-500" />
            Gerenciamento de Vídeos
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 mt-0.5">
            Cadastre, pesquise, edite e controle o status do acervo salvo no banco.
          </p>
        </div>

        <button
          onClick={onAddNew}
          className="flex items-center justify-center gap-2 min-h-[44px] rounded-xl bg-rose-600 hover:bg-rose-500 px-5 text-xs font-semibold text-white shadow-md shadow-rose-600/20 transition active:scale-95 w-full sm:w-auto"
        >
          <Plus className="h-4 w-4" />
          <span>Cadastrar Novo Vídeo</span>
        </button>
      </div>

      {/* Alertas de Feedback / Erro */}
      {feedback && (
        <div className="flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3.5 text-xs text-emerald-300">
          <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {error && (
        <div className="flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-500/10 p-3.5 text-xs text-rose-300">
          <AlertTriangle className="h-4 w-4 text-rose-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Barra de Filtros e Pesquisa */}
      <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-4 space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          {/* Pesquisa por título */}
          <form onSubmit={handleSearchSubmit} className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar vídeos por título..."
              className="w-full min-h-[44px] rounded-xl border border-white/[0.08] bg-zinc-950/80 pl-10 pr-3 text-xs text-white placeholder-zinc-500 focus:border-rose-500 focus:outline-none"
            />
          </form>

          {/* Filtro por Status (Segmented control) */}
          <div className="flex items-center p-1 rounded-xl bg-zinc-950 border border-white/[0.08] text-xs">
            <button
              onClick={() => setStatusFilter('all')}
              className={`min-h-[36px] px-3 rounded-lg font-medium transition active:scale-95 ${
                statusFilter === 'all'
                  ? 'bg-zinc-800 text-white font-semibold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Todos
            </button>
            <button
              onClick={() => setStatusFilter('published')}
              className={`min-h-[36px] px-3 rounded-lg font-medium transition active:scale-95 ${
                statusFilter === 'published'
                  ? 'bg-emerald-600/90 text-white font-semibold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Publicados
            </button>
            <button
              onClick={() => setStatusFilter('draft')}
              className={`min-h-[36px] px-3 rounded-lg font-medium transition active:scale-95 ${
                statusFilter === 'draft'
                  ? 'bg-amber-600/90 text-white font-semibold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Rascunhos
            </button>
          </div>

          {/* Filtro por Categoria */}
          {categories.length > 1 && (
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="min-h-[44px] rounded-xl border border-white/[0.08] bg-zinc-950/80 px-3 text-xs text-white focus:border-rose-500 focus:outline-none"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c === 'Todas' ? 'Todas as Categorias' : c}
                </option>
              ))}
            </select>
          )}

          <button
            onClick={fetchVideos}
            title="Recarregar lista"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-white/[0.08] bg-zinc-800 text-zinc-300 hover:text-white transition shrink-0 active:scale-95"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* LISTAGEM: MOBILE-FIRST CARDS (block md:hidden) */}
      <div className="block md:hidden space-y-3">
        {loading ? (
          <div className="py-16 text-center text-zinc-400">
            <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-rose-500 border-t-transparent mb-2" />
            <p className="text-xs">Consultando banco de dados...</p>
          </div>
        ) : videos.length === 0 ? (
          <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-8 text-center text-zinc-400">
            <Film className="mx-auto h-8 w-8 text-zinc-600 mb-2" />
            <p className="font-semibold text-zinc-200 text-sm">Nenhum vídeo encontrado</p>
            <p className="text-xs text-zinc-500 mt-1">Ajuste os filtros ou cadastre um novo vídeo.</p>
          </div>
        ) : (
          videos.map((video) => (
            <div
              key={video.id}
              className="rounded-2xl border border-white/[0.08] bg-zinc-900/70 p-4 space-y-3"
            >
              <div className="flex items-start gap-3">
                {/* Miniatura 16:9 */}
                <div
                  onClick={() => setVideoToPlay(video)}
                  className="relative h-16 w-28 rounded-xl overflow-hidden bg-black shrink-0 cursor-pointer active:scale-95 transition"
                >
                  <img
                    src={video.thumbnail_url}
                    alt={video.title}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        '/src/assets/images/thumb_sci_fi_thriller_1792239265919.jpg';
                    }}
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <Play className="h-4 w-4 text-white fill-current" />
                  </div>
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 text-[10px] text-zinc-400 mb-0.5">
                    <span className="font-semibold text-rose-400">{video.category}</span>
                    {video.duration && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono">{video.duration}</span>
                      </>
                    )}
                  </div>
                  <h3 className="font-semibold text-sm text-white line-clamp-1">
                    {video.title}
                  </h3>
                  <p className="text-xs text-zinc-400 line-clamp-1 mt-0.5">
                    {video.description}
                  </p>
                </div>
              </div>

              {/* Status and Action Buttons (Touch friendly >= 44px) */}
              <div className="pt-2 border-t border-white/[0.06] flex items-center justify-between gap-2">
                <button
                  onClick={() => handleToggleStatus(video)}
                  className={`min-h-[40px] px-3 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 ${
                    video.status === 'published'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  }`}
                  title="Clique para alternar o status"
                >
                  <span className="h-2 w-2 rounded-full bg-current" />
                  <span>{video.status === 'published' ? 'Publicado' : 'Rascunho'}</span>
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setVideoToView(video)}
                    className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border border-white/[0.08] bg-zinc-800 text-zinc-300 hover:text-white active:scale-95"
                    title="Ver detalhes"
                  >
                    <Eye className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => onEditVideo(video)}
                    className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border border-white/[0.08] bg-zinc-800 text-zinc-300 hover:text-white active:scale-95"
                    title="Editar vídeo"
                  >
                    <Edit3 className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setVideoToDelete(video)}
                    className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl border border-white/[0.08] bg-zinc-800 text-rose-400 hover:text-rose-300 active:scale-95"
                    title="Excluir vídeo"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* LISTAGEM: DESKTOP TABLE (hidden md:block) */}
      <div className="hidden md:block rounded-2xl border border-white/[0.08] bg-zinc-900/60 overflow-hidden shadow-xl">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-white/[0.08] bg-zinc-950/80 text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
              <th className="py-3.5 px-4">Vídeo</th>
              <th className="py-3.5 px-4">Categoria</th>
              <th className="py-3.5 px-4">Duração</th>
              <th className="py-3.5 px-4">Status</th>
              <th className="py-3.5 px-4">Data de Criação</th>
              <th className="py-3.5 px-4 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/[0.06] text-xs">
            {loading ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-zinc-400">
                  <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-rose-500 border-t-transparent mb-2" />
                  <p>Consultando banco de dados...</p>
                </td>
              </tr>
            ) : videos.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-zinc-500">
                  <Film className="mx-auto h-8 w-8 text-zinc-600 mb-2" />
                  <p className="font-semibold text-zinc-300">Nenhum vídeo encontrado</p>
                  <p className="text-[11px] text-zinc-500 mt-1">
                    {search || statusFilter !== 'all' || categoryFilter !== 'Todas'
                      ? 'Tente remover os filtros ou redefinir a busca.'
                      : 'Comece adicionando seu primeiro vídeo através do botão "Cadastrar Novo Vídeo".'}
                  </p>
                </td>
              </tr>
            ) : (
              videos.map((video) => (
                <tr key={video.id} className="hover:bg-zinc-800/40 transition group">
                  {/* Thumbnail + Título + Descrição */}
                  <td className="py-3.5 px-4 min-w-[280px]">
                    <div className="flex items-center gap-3">
                      <div 
                        onClick={() => setVideoToPlay(video)}
                        className="relative h-14 w-24 rounded-lg overflow-hidden bg-black shrink-0 cursor-pointer group-hover:ring-2 ring-rose-500/50 transition"
                      >
                        <img
                          src={video.thumbnail_url}
                          alt={video.title}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src =
                              '/src/assets/images/thumb_sci_fi_thriller_1792239265919.jpg';
                          }}
                        />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                          <Play className="h-5 w-5 text-white fill-current" />
                        </div>
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-zinc-200 truncate group-hover:text-white transition">
                          {video.title}
                        </p>
                        <p className="text-[11px] text-zinc-400 line-clamp-1 mt-0.5">
                          {video.description}
                        </p>
                        <span className="text-[10px] text-zinc-600 font-mono">
                          ID: {video.id.substring(0, 8)}...
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Categoria */}
                  <td className="py-3.5 px-4 whitespace-nowrap text-zinc-300">
                    {video.category}
                  </td>

                  {/* Duração */}
                  <td className="py-3.5 px-4 whitespace-nowrap text-zinc-400 font-mono">
                    {video.duration || '—'}
                  </td>

                  {/* Status Toggle */}
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <button
                      onClick={() => handleToggleStatus(video)}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-semibold transition ${
                        video.status === 'published'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20 hover:bg-amber-500/20'
                      }`}
                      title="Clique para alternar o status"
                    >
                      <span className="h-1.5 w-1.5 rounded-full bg-current" />
                      <span>{video.status === 'published' ? 'Publicado' : 'Rascunho'}</span>
                    </button>
                  </td>

                  {/* Data */}
                  <td className="py-3.5 px-4 whitespace-nowrap text-zinc-400 font-mono text-[11px]">
                    {new Date(video.created_at).toLocaleDateString('pt-BR')}
                  </td>

                  {/* Ações */}
                  <td className="py-3.5 px-4 whitespace-nowrap text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setVideoToView(video)}
                        className="rounded-lg p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition"
                        title="Ver detalhes"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => onEditVideo(video)}
                        className="rounded-lg p-1.5 text-zinc-400 hover:bg-zinc-800 hover:text-white transition"
                        title="Editar vídeo"
                      >
                        <Edit3 className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setVideoToDelete(video)}
                        className="rounded-lg p-1.5 text-zinc-400 hover:bg-rose-500/10 hover:text-rose-400 transition"
                        title="Excluir vídeo"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal de Detalhes do Vídeo */}
      {videoToView && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150"
          onClick={() => setVideoToView(null)}
        >
          <div 
            className="w-full max-w-lg rounded-2xl bg-zinc-900 border border-white/[0.1] p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
              <h3 className="text-base font-bold text-white">Detalhes do Registro</h3>
              <button
                onClick={() => setVideoToView(null)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center text-zinc-400 hover:text-white -mr-2"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-zinc-500 block mb-0.5">Título</span>
                <p className="font-semibold text-white text-sm">{videoToView.title}</p>
              </div>

              <div>
                <span className="text-zinc-500 block mb-0.5">Descrição</span>
                <p className="text-zinc-300 leading-relaxed bg-zinc-950/70 p-3 rounded-xl border border-white/[0.06]">
                  {videoToView.description}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-zinc-500 block mb-0.5">Categoria</span>
                  <p className="text-white font-medium">{videoToView.category}</p>
                </div>
                <div>
                  <span className="text-zinc-500 block mb-0.5">Duração</span>
                  <p className="text-white font-mono">{videoToView.duration || 'Não especificada'}</p>
                </div>
                <div>
                  <span className="text-zinc-500 block mb-0.5">Status</span>
                  <p className={videoToView.status === 'published' ? 'text-emerald-400 font-semibold' : 'text-amber-400 font-semibold'}>
                    {videoToView.status === 'published' ? 'Publicado' : 'Rascunho'}
                  </p>
                </div>
                <div>
                  <span className="text-zinc-500 block mb-0.5">Criado em</span>
                  <p className="text-white font-mono">{new Date(videoToView.created_at).toLocaleString('pt-BR')}</p>
                </div>
              </div>

              <div>
                <span className="text-zinc-500 block mb-0.5">UUID</span>
                <p className="font-mono text-[11px] text-zinc-400 break-all select-all">{videoToView.id}</p>
              </div>
            </div>

            <div className="pt-3 border-t border-white/[0.08] flex items-center justify-end gap-2">
              <button
                onClick={() => {
                  setVideoToView(null);
                  onEditVideo(videoToView);
                }}
                className="min-h-[44px] px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-white transition"
              >
                Editar
              </button>
              <button
                onClick={() => setVideoToView(null)}
                className="min-h-[44px] px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-semibold text-white transition"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmação de Exclusão */}
      {videoToDelete && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150"
          onClick={() => !deleting && setVideoToDelete(null)}
        >
          <div 
            className="w-full max-w-md rounded-2xl bg-zinc-900 border border-rose-500/30 p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-500/10 text-rose-500">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Excluir Vídeo</h3>
                <p className="text-xs text-zinc-400">Esta ação é irreversível no banco de dados.</p>
              </div>
            </div>

            <p className="text-xs text-zinc-300 leading-relaxed">
              Você tem certeza de que deseja remover o vídeo <strong className="text-white">"{videoToDelete.title}"</strong> permanentemente?
            </p>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                onClick={() => setVideoToDelete(null)}
                disabled={deleting}
                className="min-h-[44px] px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-300 transition"
              >
                Cancelar
              </button>
              <button
                onClick={handleConfirmDelete}
                disabled={deleting}
                className="min-h-[44px] px-5 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-semibold text-white shadow-md shadow-rose-600/30 transition flex items-center gap-2"
              >
                {deleting && <RefreshCw className="h-3.5 w-3.5 animate-spin" />}
                <span>{deleting ? 'Excluindo...' : 'Sim, Excluir'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Player Modal */}
      <VideoPlayerModal video={videoToPlay} onClose={() => setVideoToPlay(null)} />
    </div>
  );
};
