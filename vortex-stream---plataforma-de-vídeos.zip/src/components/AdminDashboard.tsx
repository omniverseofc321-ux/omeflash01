import React, { useState, useEffect } from 'react';
import { 
  Film, 
  CheckCircle, 
  Clock, 
  Plus, 
  ArrowRight, 
  Database, 
  ShieldCheck, 
  RefreshCw,
  Eye,
  CreditCard
} from 'lucide-react';
import { AdminStats } from '../types.ts';
import { getAdminStats } from '../lib/api.ts';

interface AdminDashboardProps {
  onNavigateTab: (tab: 'videos' | 'create' | 'plans') => void;
  onViewVideo: (id: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigateTab, onViewVideo }) => {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchStats = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await getAdminStats();
      setStats(res.stats);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Erro ao buscar métricas do dashboard.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-200">
      {/* Top Banner de Boas-Vindas */}
      <div className="rounded-3xl border border-white/[0.08] bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-zinc-950 p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-rose-400">
            <span>Painel Administrativo</span>
            <span aria-hidden="true" className="text-zinc-600">·</span>
            <span>Visão Geral</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight [text-wrap:balance]">
            Gestão de Conteúdo e Assinaturas
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 max-w-2xl leading-relaxed">
            Acompanhe indicadores do acervo e da oferta comercial com dados persistidos no banco de dados.
          </p>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto shrink-0">
          <button
            onClick={() => onNavigateTab('create')}
            className="flex-1 md:flex-initial flex items-center justify-center gap-2 min-h-[44px] rounded-xl bg-rose-600 hover:bg-rose-500 px-5 text-xs font-semibold text-white shadow-md shadow-rose-600/20 transition active:scale-95"
          >
            <Plus className="h-4 w-4" />
            <span>Cadastrar Vídeo</span>
          </button>
          <button
            onClick={fetchStats}
            title="Atualizar dados"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-white/[0.08] bg-zinc-800 text-zinc-300 hover:text-white transition active:scale-95 shrink-0"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-4 text-xs text-rose-300">
          {error}
        </div>
      )}

      {/* Grid de Cards de Métricas (2 colunas no mobile, 4 no desktop) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
            Indicadores de Conteúdo
          </span>
          <button
            onClick={() => onNavigateTab('videos')}
            className="text-xs font-semibold text-rose-400 hover:text-rose-300 flex items-center gap-1 transition"
          >
            Gerenciar Vídeos
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {/* Total Vídeos */}
          <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-4 sm:p-5">
            <span className="text-xs text-zinc-400 block truncate">Total de Vídeos</span>
            <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-white font-mono tabular-nums">
              {loading ? '...' : stats?.total ?? 0}
            </div>
            <span className="text-[11px] text-zinc-500 mt-1 block">cadastrados no banco</span>
          </div>

          {/* Publicados */}
          <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-4 sm:p-5">
            <span className="text-xs text-zinc-400 block truncate">Vídeos Publicados</span>
            <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono tabular-nums">
              {loading ? '...' : stats?.published ?? 0}
            </div>
            <span className="text-[11px] text-zinc-500 mt-1 block">no catálogo público</span>
          </div>

          {/* Rascunhos */}
          <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-4 sm:p-5">
            <span className="text-xs text-zinc-400 block truncate">Rascunhos</span>
            <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono tabular-nums">
              {loading ? '...' : stats?.drafts ?? 0}
            </div>
            <span className="text-[11px] text-zinc-500 mt-1 block">não visíveis</span>
          </div>

          {/* Categorias */}
          <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-4 sm:p-5">
            <span className="text-xs text-zinc-400 block truncate">Categorias</span>
            <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-zinc-200 font-mono tabular-nums">
              {loading ? '...' : stats?.categoriesCount ?? 0}
            </div>
            <span className="text-[11px] text-zinc-500 mt-1 block">gêneros ativos</span>
          </div>
        </div>
      </div>

      {/* Grid de Cards de Planos (Etapa 2) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
            Planos de Assinatura (Etapa 2)
          </span>
          <button
            onClick={() => onNavigateTab('plans')}
            className="text-xs font-semibold text-rose-400 hover:text-rose-300 flex items-center gap-1 transition"
          >
            Gerenciar Planos
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
          <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-4 sm:p-5">
            <span className="text-xs text-zinc-400 block">Total de Planos</span>
            <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-white font-mono tabular-nums">
              {loading ? '...' : stats?.totalPlans ?? 0}
            </div>
            <span className="text-[11px] text-zinc-500 mt-1 block">configurados no sistema</span>
          </div>

          <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-4 sm:p-5">
            <span className="text-xs text-zinc-400 block">Planos Ativos</span>
            <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono tabular-nums">
              {loading ? '...' : stats?.activePlans ?? 0}
            </div>
            <span className="text-[11px] text-zinc-500 mt-1 block">visíveis em /planos</span>
          </div>

          <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-4 sm:p-5">
            <span className="text-xs text-zinc-400 block">Planos Inativos</span>
            <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-zinc-400 font-mono tabular-nums">
              {loading ? '...' : stats?.inactivePlans ?? 0}
            </div>
            <span className="text-[11px] text-zinc-500 mt-1 block">ocultos ao público</span>
          </div>
        </div>
      </div>

      {/* Grid: Atividades Recentes + Status da Infraestrutura */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Atividades Recentes (2 colunas) */}
        <div className="lg:col-span-2 rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
            <h2 className="text-sm font-bold text-white">
              Últimos Vídeos Cadastrados
            </h2>
            <button
              onClick={() => onNavigateTab('videos')}
              className="text-xs font-semibold text-rose-400 hover:text-rose-300"
            >
              Ver todos
            </button>
          </div>

          {loading ? (
            <div className="py-12 text-center text-xs text-zinc-500">Carregando registros...</div>
          ) : !stats?.recentVideos || stats.recentVideos.length === 0 ? (
            <div className="py-8 text-center text-xs text-zinc-500">
              Nenhum vídeo cadastrado até o momento.
            </div>
          ) : (
            <div className="divide-y divide-white/[0.06]">
              {stats.recentVideos.map((item) => (
                <div key={item.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="text-xs sm:text-sm font-semibold text-zinc-200 truncate">
                      {item.title}
                    </p>
                    <div className="flex items-center gap-2 mt-0.5 text-[11px] text-zinc-500">
                      <span className="text-rose-400 font-medium">{item.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">{new Date(item.created_at).toLocaleDateString('pt-BR')}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`text-[11px] font-medium px-2 py-0.5 rounded-lg ${
                        item.status === 'published'
                          ? 'text-emerald-400 bg-emerald-500/10'
                          : 'text-amber-400 bg-amber-500/10'
                      }`}
                    >
                      {item.status === 'published' ? 'Publicado' : 'Rascunho'}
                    </span>

                    <button
                      onClick={() => onViewVideo(item.id)}
                      className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-zinc-400 hover:bg-zinc-800 hover:text-white transition"
                      title="Ver detalhes"
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Informações da Infraestrutura */}
        <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/60 p-5 sm:p-6 space-y-4">
          <h2 className="text-sm font-bold text-white border-b border-white/[0.06] pb-3">
            Infraestrutura & Segurança
          </h2>

          <div className="space-y-3 text-xs">
            <div className="rounded-xl border border-white/[0.06] bg-zinc-950/70 p-3.5 space-y-1">
              <div className="flex items-center justify-between font-semibold text-zinc-200">
                <span className="flex items-center gap-1.5">
                  <Database className="h-3.5 w-3.5 text-rose-500" />
                  Banco de Dados
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">CONECTADO</span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                SQLite com chave estrangeira e persistência em disco.
              </p>
            </div>

            <div className="rounded-xl border border-white/[0.06] bg-zinc-950/70 p-3.5 space-y-1">
              <div className="flex items-center justify-between font-semibold text-zinc-200">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="h-3.5 w-3.5 text-rose-500" />
                  Autenticação
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">SEGURO</span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                Hash scrypt com salt aleatório e sessões no servidor.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
