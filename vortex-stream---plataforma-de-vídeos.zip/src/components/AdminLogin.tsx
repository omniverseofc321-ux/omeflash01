import React, { useState } from 'react';
import { Shield, Lock, Mail, Eye, EyeOff, AlertCircle, ArrowLeft, Sparkles } from 'lucide-react';
import { loginApi, setAuthToken } from '../lib/api.ts';
import { AdminUser } from '../types.ts';

interface AdminLoginProps {
  onLoginSuccess: (user: AdminUser) => void;
  onNavigateHome: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLoginSuccess, onNavigateHome }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email.trim() || !password) {
      setError('Por favor, preencha todos os campos.');
      return;
    }

    try {
      setLoading(true);
      const res = await loginApi(email.trim(), password);
      setAuthToken(res.token, rememberMe);
      onLoginSuccess(res.user);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Falha na autenticação do administrador.';
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleFillDemoAdmin = () => {
    setEmail('admin@vortexstream.com');
    setPassword('admin123456');
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#090a0f] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <button
          onClick={onNavigateHome}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-400 hover:text-white mb-6 transition active:scale-95 min-h-[38px] px-3 rounded-lg hover:bg-zinc-900"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Voltar ao site público</span>
        </button>

        <div className="text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-600 text-white shadow-lg shadow-rose-600/30">
            <Shield className="h-6 w-6" />
          </div>
          <h2 className="mt-4 text-2xl font-bold tracking-tight text-white">
            Acesso Administrativo
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-zinc-400">
            Entre com suas credenciais seguras para gerenciar a plataforma.
          </p>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="rounded-3xl border border-white/[0.08] bg-zinc-900/80 p-6 sm:p-8 shadow-2xl backdrop-blur-md">
          {error && (
            <div className="mb-5 flex items-start gap-2.5 rounded-xl border border-rose-500/30 bg-rose-500/10 p-3.5 text-xs text-rose-300">
              <AlertCircle className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-1.5">
                E-mail do Administrador
              </label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5">
                  <Mail className="h-4 w-4 text-zinc-500" />
                </div>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@vortexstream.com"
                  className="block w-full min-h-[44px] rounded-xl border border-white/[0.08] bg-zinc-950/80 pl-10 pr-3 text-sm text-white placeholder-zinc-500 focus:border-rose-500 focus:ring-1 focus:ring-rose-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-300 mb-1.5">
                Senha de Acesso
              </label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5">
                  <Lock className="h-4 w-4 text-zinc-500" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="block w-full min-h-[44px] rounded-xl border border-white/[0.08] bg-zinc-950/80 pl-10 pr-11 text-sm text-white placeholder-zinc-500 focus:border-rose-500 focus:ring-1 focus:ring-rose-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-zinc-500 hover:text-zinc-300 transition"
                  aria-label="Alternar exibição de senha"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <label className="flex items-center gap-2 cursor-pointer text-zinc-400">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-zinc-700 bg-zinc-950 text-rose-600 focus:ring-rose-500 focus:ring-offset-0"
                />
                <span>Lembrar neste navegador</span>
              </label>
              <span className="text-zinc-500 text-[11px]">Área restrita</span>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[48px] rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-semibold text-white shadow-md shadow-rose-600/30 transition active:scale-[0.98] flex items-center justify-center gap-2"
            >
              <Shield className="h-4 w-4" />
              <span>{loading ? 'Validando acesso...' : 'Acessar Painel'}</span>
            </button>
          </form>

          {/* Helper rápido de credenciais para ambiente de desenvolvimento */}
          <div className="mt-6 pt-5 border-t border-white/[0.08]">
            <button
              type="button"
              onClick={handleFillDemoAdmin}
              className="w-full min-h-[40px] flex items-center justify-center gap-1.5 rounded-xl border border-white/[0.06] bg-zinc-950/60 text-xs text-zinc-400 hover:text-white hover:bg-zinc-800 transition active:scale-95"
            >
              <Sparkles className="h-3.5 w-3.5 text-rose-400" />
              <span>Preencher credenciais de administrador</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
