import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Search, 
  Clock, 
  RefreshCw, 
  CreditCard, 
  ArrowRight,
  Sparkles,
  Film
} from 'lucide-react';
import { Video } from '../types.ts';
import { getPublicVideos, getPublicCategories } from '../lib/api.ts';
import { VideoPlayerModal } from './VideoPlayerModal.tsx';

interface PublicHomeProps {
  onNavigateToAdmin: () => void;
  onNavigateToPlans?: () => void;
}

export const PublicHome: React.FC<PublicHomeProps> = ({ onNavigateToAdmin, onNavigateToPlans }) => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('Todas');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeVideo, setActiveVideo] = useState<Video | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);
      const [videosRes, catsRes] = await Promise.all([
        getPublicVideos(selectedCategory, searchQuery),
        getPublicCategories(),
      ]);
      setVideos(videosRes.videos);
      setCategories(['Todas', ...catsRes.categories]);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Falha ao carregar catálogo de vídeos.';
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedCategory]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadData();
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col pb-24 sm:pb-12">
      {/* Hero Section — Estilo Clean & Leve com Detalhes em Laranja */}
      <section className="relative overflow-hidden border-b border-slate-200 bg-gradient-to-b from-orange-50/40 via-white to-white py-12 sm:py-20">
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-5">
          {/* Tag de destaque */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-semibold tracking-wide">
            <Sparkles className="h-3.5 w-3.5 text-orange-500" />
            <span>Streaming & Produções Originais</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-tight max-w-3xl mx-auto [text-wrap:balance]">
            Histórias exclusivas com padrão cinematográfico
          </h1>

          <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto leading-relaxed [text-wrap:balance]">
            Explore nosso acervo com documentários premiados, ficção científica e produções originais transmitidas em alta definição.
          </p>

          {/* Quick CTAs (44px min touch height) */}
          <div className="pt-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 max-w-md mx-auto">
            {onNavigateToPlans && (
              <button
                onClick={onNavigateToPlans}
                className="flex items-center justify-center gap-2 min-h-[48px] px-6 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold shadow-sm shadow-orange-500/25 transition active:scale-[0.98]"
              >
                <CreditCard className="h-4 w-4" />
                <span>Ver Planos de Assinatura</span>
              </button>
            )}

            <a
              href="#catalogo"
              className="flex items-center justify-center gap-2 min-h-[48px] px-6 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-sm font-medium transition active:scale-[0.98] shadow-2xs"
            >
              <Play className="h-4 w-4 fill-current text-orange-500" />
              <span>Explorar Catálogo</span>
            </a>
          </div>
        </div>
      </section>

      {/* Catálogo de Vídeos Section */}
      <section id="catalogo" className="flex-1 py-8 sm:py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        {/* Barra de Filtros e Busca Responsiva */}
        <div className="space-y-4 mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Catálogo em Exibição
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {videos.length} título(s) disponível(is) para reprodução imediata
              </p>
            </div>

            {/* Barra de Busca (44px min height) */}
            <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 w-full sm:w-80">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Pesquisar por título..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full min-h-[44px] rounded-lg border border-slate-200 bg-white pl-10 pr-3 text-sm text-slate-900 placeholder-slate-400 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 focus:outline-none transition"
                />
              </div>
              <button
                type="submit"
                className="min-h-[44px] px-4 rounded-lg bg-orange-500 hover:bg-orange-600 text-xs font-semibold text-white transition shrink-0 active:scale-95 shadow-2xs"
              >
                Buscar
              </button>
              {(searchQuery || selectedCategory !== 'Todas') && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('Todas');
                    loadData();
                  }}
                  title="Limpar filtros"
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 hover:text-slate-800 hover:bg-slate-50 transition shrink-0 active:scale-95"
                >
                  <RefreshCw className="h-4 w-4" />
                </button>
              )}
            </form>
          </div>

          {/* Categorias (Segmented Pills com rolagem suave no celular) */}
          {categories.length > 1 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`min-h-[40px] px-4 rounded-lg text-xs font-medium whitespace-nowrap transition active:scale-95 ${
                    selectedCategory === cat
                      ? 'bg-orange-500 text-white font-semibold shadow-xs'
                      : 'bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Feedback de Carregamento / Erro / Vazio */}
        {loading ? (
          <div className="py-24 text-center">
            <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-orange-500 border-t-transparent mb-3" />
            <p className="text-xs text-slate-500 font-medium">Carregando acervo de vídeos...</p>
          </div>
        ) : error ? (
          <div className="rounded-xl border border-red-200 bg-red-50/70 p-6 text-center text-red-700 max-w-md mx-auto">
            <p className="text-xs sm:text-sm font-medium">{error}</p>
            <button
              onClick={loadData}
              className="mt-4 min-h-[44px] px-5 rounded-lg bg-orange-500 text-xs font-semibold text-white hover:bg-orange-600 transition shadow-2xs"
            >
              Recarregar
            </button>
          </div>
        ) : videos.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-8 sm:p-12 text-center max-w-md mx-auto">
            <Film className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-800">Nenhum vídeo publicado encontrado</p>
            <p className="mt-1 text-xs text-slate-500">
              {searchQuery || selectedCategory !== 'Todas'
                ? 'Tente ajustar os filtros ou os termos pesquisados.'
                : 'Cadastre novos vídeos no painel administrativo para que apareçam aqui.'}
            </p>
          </div>
        ) : (
          /* Grade de Cards de Vídeo (Mobile 1 col, Tablet 2 cols, Desktop 3-4 cols) */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {videos.map((video) => (
              <div
                key={video.id}
                onClick={() => setActiveVideo(video)}
                className="group cursor-pointer rounded-xl border border-slate-200 bg-white hover:border-orange-300 hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col active:scale-[0.99]"
              >
                {/* 16:9 Thumbnail */}
                <div className="relative aspect-video w-full overflow-hidden bg-slate-100">
                  <img
                    src={video.thumbnail_url}
                    alt={video.title}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        '/images/thumb_sci_fi_thriller_1792239265919.jpg';
                    }}
                  />
                  
                  {/* Gradiente sutil inferior */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

                  {/* Play Button Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-85 group-hover:opacity-100 transition">
                    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white/90 text-slate-900 shadow-md group-hover:bg-orange-500 group-hover:text-white transition">
                      <Play className="h-4 w-4 fill-current ml-0.5" />
                    </div>
                  </div>

                  {/* Duração formatada no canto */}
                  {video.duration && (
                    <span className="absolute bottom-2 right-2 flex items-center gap-1 rounded bg-slate-900/80 px-2 py-0.5 text-[10px] font-mono font-medium text-white backdrop-blur-xs">
                      <Clock className="h-2.5 w-2.5" />
                      {video.duration}
                    </span>
                  )}
                </div>

                {/* Conteúdo do Card */}
                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    {/* Metadados Limpos */}
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-1">
                      <span className="font-semibold text-orange-600">{video.category}</span>
                      <span aria-hidden="true" className="text-slate-300">·</span>
                      <span>{new Date(video.created_at).toLocaleDateString('pt-BR')}</span>
                    </div>

                    <h3 className="font-semibold text-sm text-slate-900 group-hover:text-orange-600 transition-colors line-clamp-1 leading-snug">
                      {video.title}
                    </h3>

                    <p className="mt-1 text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {video.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                    <span>Full HD / 4K</span>
                    <span className="font-semibold text-orange-600 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                      Assistir
                      <ArrowRight className="h-3 w-3" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Seção Comercial de Planos (Banner Promocional Integrado) */}
      {onNavigateToPlans && (
        <section className="border-t border-slate-200 bg-slate-50/50 py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto rounded-2xl border border-orange-200/80 bg-gradient-to-r from-orange-50/60 to-white p-6 sm:p-10 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xs">
            <div className="space-y-1.5 text-center sm:text-left">
              <span className="text-[11px] font-bold text-orange-600 uppercase tracking-wider">
                Assinatura Premium
              </span>
              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Acesse todas as produções sem limites
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 max-w-xl leading-relaxed">
                Planos flexíveis mensal, trimestral ou anual com 4K, downloads e múltiplas telas simultâneas.
              </p>
            </div>

            <button
              onClick={onNavigateToPlans}
              className="w-full sm:w-auto shrink-0 flex items-center justify-center gap-2 min-h-[44px] px-6 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold shadow-sm shadow-orange-500/20 transition active:scale-95"
            >
              <span>Conhecer Planos</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </section>
      )}

      {/* Footer Minimalista */}
      <footer className="border-t border-slate-200 py-8 px-4 sm:px-6 lg:px-8 text-xs text-slate-500 bg-white">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <span className="font-semibold text-slate-800">Vortex Stream</span>
            <span className="mx-2 text-slate-300">·</span>
            <span>Plataforma de Streaming e Distribuição Audiovisual</span>
          </div>

          <div className="flex items-center gap-4">
            {onNavigateToPlans && (
              <button onClick={onNavigateToPlans} className="hover:text-slate-900 transition">
                Planos
              </button>
            )}
            <button onClick={onNavigateToAdmin} className="hover:text-slate-900 transition">
              Acesso Administrativo
            </button>
          </div>
        </div>
      </footer>

      {/* Modal do Player */}
      <VideoPlayerModal video={activeVideo} onClose={() => setActiveVideo(null)} />
    </div>
  );
};
