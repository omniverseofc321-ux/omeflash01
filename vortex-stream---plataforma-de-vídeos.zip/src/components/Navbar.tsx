import React from 'react';
import { Film, Shield, LogOut, ArrowLeft, CreditCard } from 'lucide-react';
import { AdminUser } from '../types.ts';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  adminUser: AdminUser | null;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPath,
  onNavigate,
  adminUser,
  onLogout,
}) => {
  const isAdminArea = currentPath.startsWith('/admin');

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 bg-white/95 backdrop-blur-md">
      <div className="mx-auto flex h-14 sm:h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        {/* Brand / Logo */}
        <button
          onClick={() => onNavigate('/')}
          className="flex items-center gap-2.5 text-left transition hover:opacity-95 active:scale-95 shrink-0"
          aria-label="Página Inicial Vortex Stream"
        >
          <div className="flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-lg bg-orange-500 text-white shadow-sm shadow-orange-500/20">
            <Film className="h-4 w-4 sm:h-4.5 sm:w-4.5" />
          </div>
          <div className="flex items-center gap-2 whitespace-nowrap">
            <span className="font-extrabold text-base sm:text-lg tracking-tight text-slate-900 font-sans">
              Vortex<span className="text-orange-500">Stream</span>
            </span>
            {isAdminArea && (
              <span className="inline-flex items-center rounded-md bg-orange-50 px-2 py-0.5 text-[10px] font-semibold text-orange-700 ring-1 ring-inset ring-orange-600/20 uppercase tracking-wider">
                Admin
              </span>
            )}
          </div>
        </button>

        {/* Navigation Links (Desktop) */}
        {!isAdminArea ? (
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => onNavigate('/')}
              className={`whitespace-nowrap transition-colors px-3 py-1.5 rounded-lg ${
                currentPath === '/' 
                  ? 'text-orange-600 font-semibold bg-orange-50' 
                  : 'hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Catálogo
            </button>
            <button
              onClick={() => onNavigate('/planos')}
              className={`whitespace-nowrap transition-colors px-3 py-1.5 rounded-lg ${
                currentPath === '/planos' 
                  ? 'text-orange-600 font-semibold bg-orange-50' 
                  : 'hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Planos & Preços
            </button>
          </nav>
        ) : (
          <div className="hidden md:flex items-center text-xs text-slate-500 font-medium">
            Painel de Controle Administrativo
          </div>
        )}

        {/* Action Controls */}
        <div className="flex items-center gap-2.5 shrink-0">
          {isAdminArea ? (
            adminUser ? (
              <div className="flex items-center gap-2">
                <div className="hidden sm:block text-right pr-1">
                  <div className="text-xs font-semibold text-slate-900 truncate max-w-[140px]">{adminUser.name}</div>
                  <div className="text-[10px] text-slate-500 font-mono truncate max-w-[140px]">{adminUser.email}</div>
                </div>

                <button
                  onClick={() => onNavigate('/')}
                  className="flex items-center gap-1.5 min-h-[44px] rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition active:scale-95"
                >
                  <ArrowLeft className="h-3.5 w-3.5 text-slate-500" />
                  <span className="hidden sm:inline">Ver Site</span>
                  <span className="sm:hidden">Site</span>
                </button>

                <button
                  onClick={onLogout}
                  className="flex items-center gap-1.5 min-h-[44px] rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-600 hover:text-red-600 hover:border-red-200 hover:bg-red-50/50 transition active:scale-95"
                  title="Encerrar sessão"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Sair</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => onNavigate('/')}
                className="flex items-center gap-1.5 min-h-[44px] rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 hover:text-slate-900 transition active:scale-95"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                <span>Voltar</span>
              </button>
            )
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('/planos')}
                className="flex items-center gap-1.5 min-h-[44px] rounded-lg bg-orange-500 hover:bg-orange-600 text-white px-3.5 sm:px-4 py-2 text-xs font-semibold shadow-xs shadow-orange-500/20 transition active:scale-95"
              >
                <CreditCard className="h-3.5 w-3.5" />
                <span>Assinar</span>
              </button>

              <button
                onClick={() => onNavigate('/admin')}
                className="hidden sm:flex items-center gap-1.5 min-h-[44px] rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 px-3 py-2 text-xs font-medium transition active:scale-95"
                title="Acessar painel administrativo"
              >
                <Shield className="h-3.5 w-3.5 text-slate-400" />
                <span>Admin</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
