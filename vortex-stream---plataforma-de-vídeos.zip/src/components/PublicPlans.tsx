import React, { useState, useEffect } from 'react';
import { 
  Check, 
  ArrowLeft, 
  CreditCard, 
  AlertCircle,
  HelpCircle,
  X,
  Sparkles
} from 'lucide-react';
import { Plan, BillingInterval } from '../types.ts';
import { getPublicPlans } from '../lib/api.ts';

interface PublicPlansProps {
  onNavigateHome: () => void;
  onNavigateToAdmin: () => void;
}

export const PublicPlans: React.FC<PublicPlansProps> = ({ onNavigateHome, onNavigateToAdmin }) => {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [intervalFilter, setIntervalFilter] = useState<'all' | BillingInterval>('all');
  const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<Plan | null>(null);

  const fetchPlans = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await getPublicPlans();
      setPlans(res.plans);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Erro ao carregar planos disponíveis.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPlans();
  }, []);

  const formatPrice = (cents: number, currency: string) => {
    const value = cents / 100;
    if (currency === 'BRL') {
      return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
    }
    if (currency === 'USD') {
      return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
    }
    if (currency === 'EUR') {
      return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(value);
    }
    return `${currency} ${value.toFixed(2)}`;
  };

  const getIntervalLabel = (interval: BillingInterval, count: number = 1) => {
    switch (interval) {
      case 'month':
        return count === 1 ? 'mês' : `${count} meses`;
      case 'quarter':
        return 'trimestre';
      case 'semester':
        return 'semestre';
      case 'year':
        return 'ano';
      default:
        return interval;
    }
  };

  const getMonthlyEquivalent = (cents: number, interval: BillingInterval, currency: string) => {
    let months = 1;
    if (interval === 'quarter') months = 3;
    if (interval === 'semester') months = 6;
    if (interval === 'year') months = 12;

    if (months <= 1) return null;

    const monthlyCents = Math.round(cents / months);
    return `${formatPrice(monthlyCents, currency)} / mês`;
  };

  const filteredPlans = plans.filter((p) => {
    if (intervalFilter === 'all') return true;
    return p.billing_interval === intervalFilter;
  });

  return (
    <div className="min-h-screen bg-[#090a0f] text-zinc-100 flex flex-col pb-24 sm:pb-12">
      {/* Header da Página de Preços */}
      <section className="border-b border-white/[0.08] bg-gradient-to-b from-zinc-900/60 to-[#090a0f] py-12 sm:py-16 px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-3xl mx-auto space-y-4">
          <button
            onClick={onNavigateHome}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-400 hover:text-white transition active:scale-95 min-h-[38px] px-3 rounded-lg hover:bg-zinc-900"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Voltar ao catálogo</span>
          </button>

          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white [text-wrap:balance]">
            Escolha o plano ideal para você
          </h1>

          <p className="text-xs sm:text-sm text-zinc-400 max-w-xl mx-auto leading-relaxed [text-wrap:balance]">
            Acesso ilimitado ao streaming em alta definição. Sem taxas ocultas, cancele quando desejar.
          </p>

          {/* Segmented Control para Filtro de Ciclos (Touch friendly) */}
          <div className="pt-2 inline-flex items-center p-1 rounded-2xl bg-zinc-900 border border-white/[0.08] text-xs font-medium max-w-full overflow-x-auto">
            <button
              onClick={() => setIntervalFilter('all')}
              className={`min-h-[40px] px-4 rounded-xl transition whitespace-nowrap active:scale-95 ${
                intervalFilter === 'all'
                  ? 'bg-zinc-100 text-zinc-950 font-bold shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Todos
            </button>
            <button
              onClick={() => setIntervalFilter('month')}
              className={`min-h-[40px] px-4 rounded-xl transition whitespace-nowrap active:scale-95 ${
                intervalFilter === 'month'
                  ? 'bg-zinc-100 text-zinc-950 font-bold shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Mensal
            </button>
            <button
              onClick={() => setIntervalFilter('quarter')}
              className={`min-h-[40px] px-4 rounded-xl transition whitespace-nowrap active:scale-95 ${
                intervalFilter === 'quarter'
                  ? 'bg-zinc-100 text-zinc-950 font-bold shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Trimestral
            </button>
            <button
              onClick={() => setIntervalFilter('year')}
              className={`min-h-[40px] px-4 rounded-xl transition whitespace-nowrap active:scale-95 ${
                intervalFilter === 'year'
                  ? 'bg-zinc-100 text-zinc-950 font-bold shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Anual
            </button>
          </div>
        </div>
      </section>

      {/* Grid de Cards de Planos (Mobile-First: vertical stack em celulares; 2-3 colunas em telas maiores) */}
      <section className="flex-1 max-w-6xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {loading ? (
          <div className="py-24 text-center">
            <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-rose-500 border-t-transparent mb-3" />
            <p className="text-xs text-zinc-400 font-medium">Consultando planos disponíveis...</p>
          </div>
        ) : error ? (
          <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-6 text-center text-rose-300 max-w-md mx-auto">
            <p className="text-xs sm:text-sm font-medium">{error}</p>
            <button
              onClick={fetchPlans}
              className="mt-4 min-h-[44px] px-5 rounded-xl bg-rose-600 text-xs font-semibold text-white hover:bg-rose-500 transition"
            >
              Tentar Novamente
            </button>
          </div>
        ) : filteredPlans.length === 0 ? (
          <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/40 p-8 text-center max-w-md mx-auto">
            <p className="text-sm font-semibold text-zinc-300">Nenhum plano ativo encontrado</p>
            <p className="mt-1 text-xs text-zinc-500">
              Não há planos disponíveis para este período no momento.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-stretch">
            {filteredPlans.map((plan) => {
              const monthlyEquivalent = getMonthlyEquivalent(plan.price_in_cents, plan.billing_interval, plan.currency);

              return (
                <div
                  key={plan.id}
                  className={`relative rounded-3xl flex flex-col justify-between p-6 sm:p-7 transition-all ${
                    plan.is_featured
                      ? 'bg-zinc-900/90 border-2 border-rose-600 shadow-xl shadow-rose-950/20'
                      : 'bg-zinc-900/50 border border-white/[0.08] hover:border-zinc-700'
                  }`}
                >
                  <div className="space-y-4">
                    {/* Cabeçalho do Plano */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="text-xl font-bold text-white">{plan.name}</h3>
                        {plan.is_featured && (
                          <span className="text-[11px] font-semibold tracking-wider text-rose-400 uppercase">
                            Recomendado
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-zinc-400 leading-relaxed">
                        {plan.description}
                      </p>
                    </div>

                    {/* Preço de Destaque (Tabular Numerals) */}
                    <div className="py-3 border-y border-white/[0.06]">
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-mono tabular-nums">
                          {formatPrice(plan.price_in_cents, plan.currency)}
                        </span>
                        <span className="text-xs text-zinc-400 font-medium">
                          / {getIntervalLabel(plan.billing_interval, plan.interval_count)}
                        </span>
                      </div>

                      {monthlyEquivalent && (
                        <div className="text-[11px] text-emerald-400 font-medium mt-1 font-mono">
                          Equivalente a {monthlyEquivalent}
                        </div>
                      )}

                      <div className="text-[11px] text-zinc-400 mt-1">
                        {plan.auto_renewal
                          ? 'Renovação recorrente · Cancele a qualquer momento'
                          : 'Cobrança avulsa sem renovação automática'}
                      </div>
                    </div>

                    {/* Lista de Benefícios */}
                    <div className="space-y-3 pt-1">
                      <div className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider">
                        Vantagens inclusas
                      </div>
                      <div className="space-y-2.5">
                        {plan.benefits.map((b, idx) => (
                          <div key={idx} className="flex items-start gap-2.5 text-xs text-zinc-200">
                            <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded bg-rose-500/10 text-rose-400 mt-0.5">
                              <Check className="h-3 w-3 stroke-[2.5]" />
                            </span>
                            <span className="leading-snug">{b}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Botão de Contratação (44px min touch target) */}
                  <div className="pt-6 mt-6 border-t border-white/[0.06]">
                    <button
                      onClick={() => setSelectedPlanForCheckout(plan)}
                      className={`w-full min-h-[48px] rounded-xl flex items-center justify-center gap-2 text-xs font-semibold transition active:scale-[0.98] ${
                        plan.is_featured
                          ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/30'
                          : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-100 border border-white/[0.08]'
                      }`}
                    >
                      <CreditCard className="h-4 w-4" />
                      <span>Assinar {plan.name}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Seção FAQ */}
      <section className="border-t border-white/[0.08] bg-zinc-900/20 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="text-center space-y-1">
            <h2 className="text-lg sm:text-xl font-bold text-white flex items-center justify-center gap-2">
              <HelpCircle className="h-4 w-4 text-rose-500" />
              Perguntas Frequentes
            </h2>
            <p className="text-xs text-zinc-400">Tire suas dúvidas sobre a assinatura do Vortex Stream</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
            <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/40 p-5">
              <h4 className="text-xs font-semibold text-zinc-200">Como funciona o cancelamento?</h4>
              <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed">
                Você pode cancelar sua assinatura quando quiser, diretamente na sua conta, sem burocracia ou multas rescisórias.
              </p>
            </div>

            <div className="rounded-2xl border border-white/[0.08] bg-zinc-900/40 p-5">
              <h4 className="text-xs font-semibold text-zinc-200">Formas de pagamento</h4>
              <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed">
                A integração com gateways de pagamento seguros (Cartão de Crédito, Pix e Boleto) será disponibilizada na próxima etapa do sistema.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Modal Provisório de Checkout — Bottom Sheet no Mobile, Dialog no Desktop */}
      {selectedPlanForCheckout && (
        <div 
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150"
          onClick={() => setSelectedPlanForCheckout(null)}
        >
          <div 
            className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl bg-zinc-900 border border-white/[0.1] p-5 sm:p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Grab handle no mobile */}
            <div className="w-10 h-1 bg-zinc-700 rounded-full mx-auto sm:hidden mb-2" />

            <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
              <div className="flex items-center gap-2.5">
                <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-rose-500/10 text-rose-500">
                  <CreditCard className="h-4 w-4" />
                </span>
                <div>
                  <h3 className="text-sm font-bold text-white">Etapa Provisória de Contratação</h3>
                  <p className="text-[11px] text-zinc-400">Etapa 2 — Configuração de Planos</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPlanForCheckout(null)}
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-zinc-400 hover:text-white"
                aria-label="Fechar"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Resumo */}
            <div className="rounded-xl bg-zinc-950/80 border border-white/[0.06] p-3.5 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-zinc-400">Plano Selecionado:</span>
                <span className="font-semibold text-white">{selectedPlanForCheckout.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Valor Cadastrado:</span>
                <span className="font-bold text-emerald-400 font-mono tabular-nums">
                  {formatPrice(selectedPlanForCheckout.price_in_cents, selectedPlanForCheckout.currency)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Frequência:</span>
                <span className="capitalize">{getIntervalLabel(selectedPlanForCheckout.billing_interval, selectedPlanForCheckout.interval_count)}</span>
              </div>
            </div>

            {/* Aviso informativo e honesto */}
            <div className="rounded-xl border border-amber-500/20 bg-amber-500/10 p-3.5 flex items-start gap-2.5">
              <AlertCircle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-[11px] text-amber-200/90 leading-relaxed space-y-1">
                <p className="font-semibold text-amber-300">
                  Integração de pagamento em preparação (Etapa 3)
                </p>
                <p>
                  O banco de dados e as regras de planos estão ativos. O checkout real com gateway de pagamentos 
                  será implementado na Etapa 3. Nenhuma cobrança foi efetuada.
                </p>
              </div>
            </div>

            <button
              onClick={() => setSelectedPlanForCheckout(null)}
              className="w-full min-h-[48px] rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-white transition active:scale-[0.98]"
            >
              Compreendido, Fechar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
