import { Video, AdminUser, AdminStats, VideoFormData, VideoStatus, Plan, PlanFormData, PlanStatus } from '../types.ts';

const TOKEN_KEY = 'vortex_admin_token';

export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY);
}

export function setAuthToken(token: string, remember: boolean = true): void {
  if (remember) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    sessionStorage.setItem(TOKEN_KEY, token);
  }
}

export function clearAuthToken(): void {
  localStorage.removeItem(TOKEN_KEY);
  sessionStorage.removeItem(TOKEN_KEY);
}

const API_BASE_URL = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const url = endpoint.startsWith('http') ? endpoint : `${API_BASE_URL}${endpoint}`;

  const response = await fetch(url, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    let errorMsg = data.error;
    if (!errorMsg) {
      if (response.status === 404) {
        errorMsg = `Erro na requisição (404): Endpoint '${endpoint}' não encontrado. Caso o site esteja no Netlify, lembre-se que o backend Node.js (Express/SQLite) não roda automaticamente em hospedagens estáticas. Configure VITE_API_URL apontando para o seu backend ou hospede o projeto completo no Render/Railway.`;
      } else {
        errorMsg = `Erro na requisição (${response.status})`;
      }
    }
    throw new Error(errorMsg);
  }

  return data as T;
}

// ----------------- AUTENTICAÇÃO -----------------

export async function loginApi(email: string, password: string): Promise<{ token: string; user: AdminUser }> {
  return request<{ token: string; user: AdminUser }>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
}

export async function logoutApi(): Promise<void> {
  try {
    await request('/api/auth/logout', { method: 'POST' });
  } finally {
    clearAuthToken();
  }
}

export async function getMeApi(): Promise<{ user: AdminUser }> {
  return request<{ user: AdminUser }>('/api/auth/me');
}

// ----------------- CATÁLOGO PÚBLICO -----------------

export async function getPublicVideos(category?: string, search?: string): Promise<{ videos: Video[]; count: number }> {
  const params = new URLSearchParams();
  if (category && category !== 'Todas') params.append('category', category);
  if (search && search.trim()) params.append('search', search.trim());

  const query = params.toString() ? `?${params.toString()}` : '';
  return request<{ videos: Video[]; count: number }>(`/api/videos${query}`);
}

export async function getPublicCategories(): Promise<{ categories: string[] }> {
  return request<{ categories: string[] }>('/api/categories');
}

// ----------------- PAINEL ADMINISTRATIVO -----------------

export async function getAdminStats(): Promise<{ stats: AdminStats }> {
  return request<{ stats: AdminStats }>('/api/admin/stats');
}

export async function getAdminVideos(filters?: { search?: string; status?: string; category?: string }): Promise<{
  videos: Video[];
  count: number;
  categories: string[];
}> {
  const params = new URLSearchParams();
  if (filters?.search) params.append('search', filters.search);
  if (filters?.status && filters.status !== 'all') params.append('status', filters.status);
  if (filters?.category && filters.category !== 'Todas') params.append('category', filters.category);

  const query = params.toString() ? `?${params.toString()}` : '';
  return request<{ videos: Video[]; count: number; categories: string[] }>(`/api/admin/videos${query}`);
}

export async function getAdminVideo(id: string): Promise<{ video: Video }> {
  return request<{ video: Video }>(`/api/admin/videos/${id}`);
}

export async function createAdminVideo(data: VideoFormData): Promise<{ success: boolean; message: string; video: Video }> {
  return request<{ success: boolean; message: string; video: Video }>('/api/admin/videos', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function updateAdminVideo(id: string, data: VideoFormData): Promise<{ success: boolean; message: string; video: Video }> {
  return request<{ success: boolean; message: string; video: Video }>(`/api/admin/videos/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function updateAdminVideoStatus(id: string, status: VideoStatus): Promise<{ success: boolean; message: string }> {
  return request<{ success: boolean; message: string }>(`/api/admin/videos/${id}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
}

export async function deleteAdminVideo(id: string): Promise<{ success: boolean; message: string }> {
  return request<{ success: boolean; message: string }>(`/api/admin/videos/${id}`, {
    method: 'DELETE',
  });
}

// ----------------- PLANOS DE ASSINATURA (ETAPA 2) -----------------

export async function getPublicPlans(): Promise<{ plans: Plan[]; count: number }> {
  return request<{ plans: Plan[]; count: number }>('/api/plans');
}

export async function getPublicPlan(id: string): Promise<{ plan: Plan }> {
  return request<{ plan: Plan }>(`/api/plans/${id}`);
}

export async function getAdminPlans(filters?: { search?: string; status?: string }): Promise<{
  plans: Plan[];
  count: number;
}> {
  const params = new URLSearchParams();
  if (filters?.search) params.append('search', filters.search);
  if (filters?.status && filters.status !== 'all') params.append('status', filters.status);

  const query = params.toString() ? `?${params.toString()}` : '';
  return request<{ plans: Plan[]; count: number }>(`/api/admin/plans${query}`);
}

export async function getAdminPlan(id: string): Promise<{ plan: Plan }> {
  return request<{ plan: Plan }>(`/api/admin/plans/${id}`);
}

export async function createAdminPlan(data: PlanFormData): Promise<{ success: boolean; message: string; plan: Plan }> {
  return request<{ success: boolean; message: string; plan: Plan }>('/api/admin/plans', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function updateAdminPlan(id: string, data: PlanFormData): Promise<{ success: boolean; message: string; plan: Plan }> {
  return request<{ success: boolean; message: string; plan: Plan }>(`/api/admin/plans/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function updateAdminPlanStatus(id: string, status: PlanStatus): Promise<{ success: boolean; message: string }> {
  return request<{ success: boolean; message: string }>(`/api/admin/plans/${id}/status`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
}

export async function deleteAdminPlan(id: string): Promise<{ success: boolean; message: string }> {
  return request<{ success: boolean; message: string }>(`/api/admin/plans/${id}`, {
    method: 'DELETE',
  });
}

