# Guia de Publicação e Hospedagem (Netlify, Render, Railway)

## Por que ocorreu o "Erro na requisição (404)" no Netlify?

O projeto **Vortex Stream** é uma aplicação **Full-Stack**:
1. **Frontend**: Feito em React + Vite + Tailwind CSS.
2. **Backend**: Feito em Node.js + Express + banco de dados SQLite (`server.ts` e pasta `server/`), responsável pelas rotas `/api/videos`, `/api/plans`, `/api/auth`, etc.

O **Netlify é um provedor de hospedagem de arquivos estáticos (HTML/CSS/JS)**. Quando você conecta o repositório no Netlify, ele executa apenas `npm run build` (que gera os arquivos estáticos na pasta `dist/`). **O Netlify não executa o servidor Node.js (`server.ts`)**.

Assim, quando o site no Netlify tenta buscar `/api/videos` ou `/api/plans`, o Netlify procura arquivos estáticos com esses nomes, não encontra nada e devolve **404 (Not Found)**.

---

## Como colocar o site no ar funcionando 100%

### OPÇÃO 1 (Recomendada e Mais Fácil): Hospedar o projeto completo no Render.com

O [Render.com](https://render.com) possui plano gratuito para **Web Services**, suporta Node.js nativamente e roda tanto o frontend quanto o backend Express e o banco de dados em um único lugar!

1. Crie uma conta gratuita em [render.com](https://render.com).
2. Clique em **New +** > **Web Service**.
3. Conecte o repositório GitHub do seu projeto.
4. Preencha as configurações:
   - **Name**: `vortex-stream` (ou o nome que preferir)
   - **Language**: `Node`
   - **Branch**: `main`
   - **Build Command**: `npm run build`
   - **Start Command**: `npm start`
5. Em **Environment Variables** (Variáveis de Ambiente), adicione:
   - `NODE_ENV`: `production`
   - `PORT`: `3000` (ou deixe o Render definir automaticamente)
   - `SESSION_SECRET`: uma frase ou chave secreta qualquer (ex: `minha-chave-super-secreta-123`)
   - `ADMIN_INITIAL_EMAIL`: `admin@vortexstream.com`
   - `ADMIN_INITIAL_PASSWORD`: `admin123456`
6. Clique em **Deploy Web Service**.
7. Pronto! O Render irá compilar o frontend e subir o servidor Node.js. Você terá uma URL pública (ex: `https://vortex-stream.onrender.com`) onde todas as funções, vídeos, planos e painel admin funcionarão perfeitamente.

---

### OPÇÃO 2: Manter o Frontend no Netlify e hospedar o Backend no Render/Railway

Se você faz questão de manter a URL do Netlify para os visitantes:

1. Suba o backend no **Render.com** seguindo os passos da **Opção 1**.
2. Copie a URL gerada pelo Render (ex: `https://vortex-api.onrender.com`).
3. No painel do seu site no **Netlify**:
   - Vá em **Site configuration** > **Environment variables**.
   - Adicione a variável:
     - **Key**: `VITE_API_URL`
     - **Value**: `https://vortex-api.onrender.com` (a URL do seu backend no Render)
   - Vá em **Deploys** e clique em **Trigger deploy** > **Clear cache and deploy site**.
4. Pronto! O frontend no Netlify agora se comunicará com o seu backend no Render sem erros de 404!

---

### Soluções já aplicadas no código para você:
- **`public/_redirects` & `netlify.toml`**: Adicionados para evitar erros 404 ao recarregar rotas como `/admin` e `/planos` no Netlify.
- **`VITE_API_URL`**: Suporte configurado em `src/lib/api.ts` para permitir conectar a qualquer servidor remoto.
- **CORS Habilitado**: O `server.ts` agora aceita requisições cross-origin para permitir que o frontend no Netlify se comunique com o servidor no Render/Railway.
