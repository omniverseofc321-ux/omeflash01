import express from 'express';
import path from 'node:path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { initDatabase } from './server/db.ts';
import { seedAdmin } from './server/seed.ts';
import { authRouter } from './server/routes/auth.ts';
import { adminRouter } from './server/routes/admin.ts';
import { publicVideosRouter } from './server/routes/videos.ts';
import { publicPlansRouter } from './server/routes/plans.ts';

dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProduction = process.env.NODE_ENV === 'production';

// Inicializa banco de dados e cria primeiro administrador caso ainda não exista
initDatabase();
seedAdmin(false);

// Middlewares essenciais
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', process.env.CORS_ORIGIN || '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

app.use(express.json());

// Rotas da API
app.use('/api/auth', authRouter);
app.use('/api/admin', adminRouter);
app.use('/api', publicVideosRouter);
app.use('/api', publicPlansRouter);

// Rota de saúde/status da API
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'Vortex Stream Platform API',
  });
});

// Captura qualquer rota sob /api/* não mapeada e responde com JSON 404 explícito
app.all('/api/*', (req, res) => {
  res.status(404).json({
    error: `Endpoint '${req.method} ${req.originalUrl}' não encontrado na API.`,
  });
});

// Integração com Vite (modo desenvolvimento) ou arquivos estáticos gerados (modo produção)
if (!isProduction) {
  const vite = await createViteServer({
    server: {
      middlewareMode: true,
      hmr: process.env.DISABLE_HMR !== 'true',
    },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  const distPath = path.resolve(process.cwd(), 'dist');
  app.use(express.static(distPath));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[Server] Vortex Stream em execução na porta ${PORT}`);
  console.log(`[Server] Painel administrativo em: http://localhost:${PORT}/admin`);
});
